import Landing from './Landing';

// Re-export Landing as the default Index page
export default Landing;
